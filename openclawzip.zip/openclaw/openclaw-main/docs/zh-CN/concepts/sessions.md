---
read_when:
  - 你查找了 docs/sessions.md；规范文档位于 docs/session.md
summary: 会话管理文档的别名
title: 会话
x-i18n:
  generated_at: "2026-02-01T20:23:55Z"
  model: claude-opus-4-5
  provider: pi
  source_hash: 7f1e39c3c07b9bb5cdcda361399cf1ce1226ebae3a797d8f93e734aa6a4d00e2
  source_path: concepts/sessions.md
  workflow: 14
---

# 会话

规范的会话管理文档位于[会话管理](/concepts/session)。
