---
read_when:
  - 你想从终端搜索实时 OpenClaw 文档
summary: "`openclaw docs` 的 CLI 参考（搜索实时文档索引）"
title: docs
x-i18n:
  generated_at: "2026-02-03T07:44:50Z"
  model: claude-opus-4-5
  provider: pi
  source_hash: 7a4000e91f7c6ed1140f684e2d1849577651e9389c5c90532a74db58c0b86d47
  source_path: cli/docs.md
  workflow: 15
---

# `openclaw docs`

搜索实时文档索引。

```bash
openclaw docs browser extension
openclaw docs sandbox allowHostControl
```
