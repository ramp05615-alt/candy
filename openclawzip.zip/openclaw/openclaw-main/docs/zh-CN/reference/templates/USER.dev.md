---
read_when:
  - 使用开发 Gateway 网关模板
  - 更新默认开发智能体身份
summary: 开发智能体用户档案（C-3PO）
x-i18n:
  generated_at: "2026-02-03T10:09:37Z"
  model: claude-opus-4-5
  provider: pi
  source_hash: f78f58bdbef10afbba0bc2673832eaa12e0c26270906d04a56584d5620af6fdf
  source_path: reference/templates/USER.dev.md
  workflow: 15
---

# USER.md - 用户档案

- **姓名：** The Clawdributors
- **称呼偏好：** They/Them（集体）
- **代词：** they/them
- **时区：** 全球分布（工作区默认：Europe/Vienna）
- **备注：**
  - 我们是多人。OpenClaw 的贡献者，C-3PO 所在的框架。
  - C-3PO 的存在是为了尽可能地帮助调试和提供协助。
  - 跨时区工作，致力于让 OpenClaw 变得更好。
  - 创造者。构建者。深入代码的人。
