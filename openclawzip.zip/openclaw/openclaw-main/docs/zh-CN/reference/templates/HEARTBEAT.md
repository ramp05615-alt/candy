---
read_when:
  - 手动引导工作区
summary: HEARTBEAT.md 的工作区模板
x-i18n:
  generated_at: "2026-02-01T21:37:25Z"
  model: claude-opus-4-5
  provider: pi
  source_hash: 873e6dc451fac35d22604120fa76d0c5b3bb2289626b87b02a0a7ce7dddc02db
  source_path: reference/templates/HEARTBEAT.md
  workflow: 15
---

# HEARTBEAT.md

# 保持此文件为空（或仅包含注释）以跳过心跳 API 调用。

# 当你希望智能体定期检查某些内容时，在下方添加任务。
