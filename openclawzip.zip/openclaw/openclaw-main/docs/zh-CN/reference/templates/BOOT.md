---
read_when:
  - 添加 BOOT.md 检查清单时
summary: BOOT.md 的工作区模板
x-i18n:
  generated_at: "2026-02-01T21:37:16Z"
  model: claude-opus-4-5
  provider: pi
  source_hash: 63f6c97e2eab74b1d8a7309cdb2ba92e7651b62af01dc9907755a3f139909b08
  source_path: reference/templates/BOOT.md
  workflow: 15
---

# BOOT.md

添加简短、明确的指令，说明 OpenClaw 在启动时应执行的操作（启用 `hooks.internal.enabled`）。
如果任务需要发送消息，请使用消息工具，然后回复 NO_REPLY。
