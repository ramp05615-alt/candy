---
read_when:
    - 手动引导工作区
summary: 用户档案记录
x-i18n:
    generated_at: "2026-02-01T21:38:04Z"
    model: claude-opus-4-5
    provider: pi
    source_hash: 508dfcd4648512df712eaf8ca5d397a925d8035bac5bf2357e44d6f52f9fa9a6
    source_path: reference/templates/USER.md
    workflow: 15
---

# USER.md - 关于你的用户

*了解你正在帮助的人。随时更新此文件。*

- **姓名：**
- **称呼方式：**
- **代词：** *（可选）*
- **时区：**
- **备注：**

## 背景

*（他们关心什么？正在做什么项目？什么让他们烦恼？什么让他们开心？随着时间推移逐步完善。）*

---

你了解得越多，就越能提供更好的帮助。但请记住——你是在了解一个人，而不是在建立档案。尊重这两者之间的区别。
